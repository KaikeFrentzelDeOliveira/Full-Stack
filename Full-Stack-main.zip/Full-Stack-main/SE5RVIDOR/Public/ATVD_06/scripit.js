const canvas = document.getElementById("meuCanvas");
const ctx = canvas.getContext("2d");

const img = new Image();
img.src = "https://cdn-icons-png.flaticon.com/512/616/616408.png"; // Exemplo: bolinha

let posX = 150;
let posY = 150;
const imgSize = 50; // tamanho da imagem

// Atualiza posição do mouse
let mouseX = posX;
let mouseY = posY;

canvas.addEventListener("mousemove", (event) => {
  const rect = canvas.getBoundingClientRect();
  mouseX = event.clientX - rect.left;
  mouseY = event.clientY - rect.top;
});

// Se o mouse sair, mantém a posição dentro do canvas
canvas.addEventListener("mouseleave", () => {
  if (mouseX < imgSize / 2) mouseX = imgSize / 2;
  if (mouseY < imgSize / 2) mouseY = imgSize / 2;
  if (mouseX > canvas.width - imgSize / 2) mouseX = canvas.width - imgSize / 2;
  if (mouseY > canvas.height - imgSize / 2) mouseY = canvas.height - imgSize / 2;
});

// Animação suave
function animar() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Aproxima a imagem do mouse
  posX += (mouseX - posX) * 0.1;
  posY += (mouseY - posY) * 0.1;

  // Impede de sair do canvas
  if (posX < imgSize / 2) posX = imgSize / 2;
  if (posY < imgSize / 2) posY = imgSize / 2;
  if (posX > canvas.width - imgSize / 2) posX = canvas.width - imgSize / 2;
  if (posY > canvas.height - imgSize / 2) posY = canvas.height - imgSize / 2;

  // Desenha imagem centralizada
  ctx.drawImage(img, posX - imgSize / 2, posY - imgSize / 2, imgSize, imgSize);

  requestAnimationFrame(animar);
}

img.onload = animar;
