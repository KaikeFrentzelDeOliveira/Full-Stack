const numeroAleatorio = Math.floor(Math.random() * 100);
console.log("Número secreto:", numeroAleatorio)

function verificar() {
  const tentativa = document.getElementById("tentativa").value;
  const mensagem = document.getElementById("mensagem");
  const corpo = document.body;

  if (tentativa === "") {
    mensagem.textContent = "Digite um número!";
    return;
  }

  const numero = parseInt(tentativa);

  if (numero === numeroAleatorio) {
    mensagem.textContent = "Parabéns! Você acertou!";
    corpo.style.setProperty("background-color", "lightgreen");
  } else if (numero > numeroAleatorio) {
    mensagem.textContent = "O número é menor!";
    corpo.style.setProperty("background-color", "lightcoral");
  } else {
    mensagem.textContent = "O número é maior!";
    corpo.style.setProperty("background-color", "lightcoral");
  }
}
