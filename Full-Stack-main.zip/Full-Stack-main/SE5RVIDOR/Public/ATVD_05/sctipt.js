const canvas = document.getElementById("meuCanvas");
const ctx = canvas.getContext("2d");

// Fundo verde-claro (céu)
ctx.fillStyle = "#8fffd7";
ctx.fillRect(0, 0, 400, 400);

// Sol
ctx.beginPath();
ctx.arc(320, 80, 40, 0, Math.PI * 2);
ctx.fillStyle = "yellow";
ctx.fill();
ctx.closePath();

// Rua / chão
ctx.fillStyle = "gray";
ctx.fillRect(0, 250, 400, 150);

// Casa
ctx.fillStyle = "#8B4513"; // marrom
ctx.fillRect(150, 150, 100, 100);

// Telhado
ctx.beginPath();
ctx.moveTo(140, 150);
ctx.lineTo(200, 100);
ctx.lineTo(260, 150);
ctx.closePath();
ctx.fillStyle = "tomato";
ctx.fill();

// Porta
ctx.fillStyle = "#5a2d0c";
ctx.fillRect(190, 200, 20, 50);

// Janelas
ctx.fillStyle = "deepskyblue";
ctx.fillRect(160, 170, 25, 25);
ctx.fillRect(215, 170, 25, 25);

// Calçada azul à esquerda
ctx.fillStyle = "#4285f4";
ctx.beginPath();
ctx.moveTo(0, 250);
ctx.lineTo(80, 250);
ctx.lineTo(80, 400);
ctx.lineTo(0, 400);
ctx.quadraticCurveTo(0, 320, 40, 300);
ctx.fill();
ctx.closePath();

// Árvores
function desenharArvore(x, y) {
  // tronco
  ctx.fillStyle = "#8B4513";
  ctx.fillRect(x + 18, y + 40, 14, 40);

  // copa
  ctx.beginPath();
  ctx.arc(x + 25, y + 35, 25, 0, Math.PI * 2);
  ctx.fillStyle = "green";
  ctx.fill();
  ctx.closePath();
}

desenharArvore(50, 180);
desenharArvore(300, 180);
